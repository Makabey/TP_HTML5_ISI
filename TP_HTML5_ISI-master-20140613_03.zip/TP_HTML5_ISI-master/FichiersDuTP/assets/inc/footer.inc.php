			</div>

			<footer>
				<?php
				$MenusID="footer_"; # chaines à ajouter aux noms de classes dans "menu.php" pour distinguer entre l'utilisation dans le header et dans le footer
				spawnMainMenu();
				?>
				<p>&copy; 2014 - Conception <mark>Olivier Berthier</mark> et <mark>Eric Robert</mark></p>
			</footer>
		</div>
	</body>
</html>
